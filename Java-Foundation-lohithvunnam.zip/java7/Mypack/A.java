package samplepackage;
 
public class A {
  public void display() {
    System.out.println("welcome to bitlabs");
  }
}