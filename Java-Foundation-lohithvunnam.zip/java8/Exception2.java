//Null Pointer Excetpion
class Exception2
  {
    public static void main(String args[])
    {
      String s=null;
      System.out.println(s.concat("hello"));
      
      
    }
  }