class Strings
  {
    public static void main(String[]args)
    {
      String s="RRR";
      String s1=new String("VSR");
      System.out.println(s);
      System.out.println(s1);
       System.out.println(" the length of the string is : "+s.length());
   System.out.println(s.compareTo(s1));
      System.out.println(s.concat(s1));

      }
    }
  
