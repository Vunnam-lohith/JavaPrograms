import java.util.*;
import java.util.Iterator;
class Iterator
  {
    public static void main(String[]args)
    {
      ArrayList vl=new ArrayList();
      
    }
  }