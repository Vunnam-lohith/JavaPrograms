class Itteration
  {
    public static void main(String args[])
    {
      int i;
      for(i=1;i<=10;i++)
        {
          System.out.println("hello world" +i);
        }
      System.out.println("iteration of i is "+i);
    }
  }