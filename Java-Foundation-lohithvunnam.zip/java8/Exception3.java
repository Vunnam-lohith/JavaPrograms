//Number Format Exception
class Exception3
  {
    public static void main(String args[])
    {
      String s="123@a";
      int x=Integer.parseInt(s);
      System.out.println("x value:"+x);
          
      
    }
  }