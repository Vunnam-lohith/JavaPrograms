// Java Program to demonstrate simple if-else statement

public class SimpleIfElse {
  public static void main(String[] args) {
	
	// Variable "time" declaration and initialization  
	int time = 20;

	// Checking the time with if 
	if (time < 18) {
	// Printing "Good Day" if time < 18
		System.out.println("Good day.");
	} 
	else {
	// Printing "Good evening" if time > 18
		System.out.println("Good evening.");
	}
 }
}