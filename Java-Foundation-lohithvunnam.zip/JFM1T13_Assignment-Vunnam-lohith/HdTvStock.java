/*  JFM1T13_Assignment4: 

      Write a program to create a class HDTV with the properties: 
         •	Brandname 
         •	Size 
      Create another class having an ArrayList and add 3 objects of HDTV into it. Display HDTV objects in sorted order of size.(Use Comparator) 

     Sample Output:
     4000 Sony 20
     2000 LG 26
     3000 MI 27
     1000 Samsung 28
*/

public class HdTvStock {

//main method

//create HdTv class object in arraylist

//add elements to that arraylist

//print values on sorted order based on size value

//use collection.sort and pass Brandname Comparator as parameters

//print result

//create HdTv class in that declare variables and pass variables as parameters


//create BrandnameComparator it implements Comparator in that create a compare method pass two parameters for comparing sizes

//access HdTv class objects

//compare sizes and return size

}