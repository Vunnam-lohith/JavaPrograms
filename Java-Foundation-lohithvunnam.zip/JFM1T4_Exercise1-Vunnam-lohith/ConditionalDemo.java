// Java Program to demonstrate simple if statement

class ConditionalDemo {
    
 public static void main(String args[]) {

    // Initializing variables
    int x = 20;
    int y = 18;

    //Checking condition x>y with if statement
    if (x > y) {  
      System.out.println("x is greater than y");
    }
 }
}