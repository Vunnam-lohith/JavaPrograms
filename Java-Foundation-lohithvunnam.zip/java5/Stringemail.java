class Stringemail
  {
    public static void main(String args[])
    {
     String s="lohithvunnam007@gmail.com";
      if(s.contains("@")&&s.contains("."))
      {
       System.out.println("it is a valid email");
        }
      else
     {
       System.out.println("invalid");
     }
    
  }
  }