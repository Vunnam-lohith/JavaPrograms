//reverse()
class StringBufferRev
  {
    public static void main(String args[])
    {
     StringBuffer sb=new StringBuffer("welcome to java");
     sb.reverse();
      System.out.println(sb);
      
    }
  }