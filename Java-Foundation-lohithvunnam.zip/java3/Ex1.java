class Ex1
  {
    public static void main(String args[])
    {
      int i;
      for(i=1;i<=10;i++)
        {
          System.out.println(i);
          if(i==5)
          {
          break;
          }
         
        }
    }
  }

class Ex1
  {
    public static void main(String args[])
    {
      int i;
      for(i=1;i<=10;i++)
        {
          if(i==5)
          {
          continue;
          }
         System.out.println(i);
        }
    }
  }