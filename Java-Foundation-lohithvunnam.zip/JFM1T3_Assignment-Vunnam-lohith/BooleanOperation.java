//JFM1T3_Assignment5:
/*
1.Write a program to initialize a boolean variable and print it's opposite value on console.

  Sample Input:true

  Expected Output:false

*/
public class BooleanOperation {
  public static void main(String[]args)
  {
        boolean a = true;
    System.out.println("the opposite value : "+(!a));
      
  }

//Define main method

//Declare a variable and initialize it as true or false 

//Print the Result using not operator 

}

//read the question and answer accordingly. you need to print opposite value of a boolean variable.
