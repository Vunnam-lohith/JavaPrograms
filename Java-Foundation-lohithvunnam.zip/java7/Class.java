import display.*;
class Class
  {
    public static void main(String args[])
    {
      A obj=new A();
      obj.display();
    }
  }