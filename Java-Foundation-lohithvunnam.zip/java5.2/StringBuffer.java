
    class StringBuffer
  {
    public static void main(String args[])
    {
      StringBuffer sb=new StringBuffer("welcome");
      System.out.println(sb);
      StringBuffer sb1=new StringBuffer("welcome");
      sb.append("bitlabs");
      System.out.println(sb1);
    }
  }
