class Assignment1 {
  public static void main(String args[]) {

    int a = 50;
    System.out.println(a);
    a += 9;
    System.out.println(a);
    int b = 40;
    b -= 4;
    System.out.println(b);
    b *= 7;
    System.out.println(b);
    b %= 5;
    System.out.println(b);
    float c = b;
    c /= 5;
    System.out.println(c);

  }
}